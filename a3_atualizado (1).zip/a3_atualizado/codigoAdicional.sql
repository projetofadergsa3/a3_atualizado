INSERT INTO `perfil` VALUES (NULL, "Usuário Teste", NOW(), 1);
