<?php

class Credor{

    public $idCredor, $idUsuario, $nomeCredor, $dataCadastro, 
    $responsavelCredor, $telefoneCredor, $celularCredor, $ativo;

    public function __construct($idCredor = NULL, $idUsuario = NULL, $nomeCredor = NULL, $dataCadastro = NULL, 
    $responsavelCredor = NULL, $telefoneCredor = NULL, $celularCredor = NULL, $ativo = NULL){

        $this->idCredor = $idCredor;
        $this->idUsuario = $idUsuario;
        $this->nomeCredor = $nomeCredor;
        $this->dataCadastro = $dataCadastro;
        $this->responsavelCredor = $responsavelCredor; 
        $this->telefoneCredor = $telefoneCredor;
        $this->celularCredor = $celularCredor;
        $this->ativo = $ativo;             
    }
}