<?php

class Lancamento{

    public $idLancamento, $idBase, $idUsuario, $idDespesa, $competenciaDespesa, $dataVencimento, 
    $valorLiquido, $valorMulta, $valorJuros, $valorCorrecao, $dataCadastro, $ativo, $observacao;

    public function __construct($idLancamento = NULL, $idBase = NULL, $idUsuario = NULL, $idDespesa = NULL, 
    $competenciaDespesa = NULL, $dataVencimento = NULL, 
    $valorLiquido = NULL, $valorMulta = NULL, $valorJuros = NULL, $valorCorrecao = NULL, 
    $dataCadastro = NULL , $ativo = NULL, $observacao = NULL){

        
        $this->idLancamento = $idLancamento;
        $this->idBase = $idBase;
        $this->idUsuario = $idUsuario;
        $this->idDespesa = $idDespesa;
        $this->competenciaDespesa = $competenciaDespesa;
        $this->dataVencimento = $dataVencimento;
        $this->valorLiquido = $valorLiquido; 
        $this->valorMulta = $valorMulta;
        $this->valorJuros = $valorJuros;
        $this->valorCorrecao = $valorCorrecao;
        $this->dataCadastro = $dataCadastro; 
        $this->ativo = $ativo;   
        $this->observacao = $observacao;          
    }

    public function getArrayCSV() {
        return array(
            $this->idLancamento,
            $this->idDespesa->idCredor->nomeCredor,
            $this->idBase->nomeBase,
            $this->idDespesa->nomeDespesa,
            $this->dataVencimento,
            $this->valorLiquido,
            $this->valorMulta,
            $this->valorJuros,
            $this->valorCorrecao,

        );
    }
}

