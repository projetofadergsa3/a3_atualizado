<?php

class Sessao{

    public $idSessao, $nomeSessao, $dataCadastro;

    public function __construct($idSessao = NULL, $nomeSessao = NULL, $dataCadastro = NULL){
    $this->idSessao = $idSessao;
    $this->nomeSessao = $nomeSessao;
    $this->dataCadastro = $dataCadastro;
    }
}