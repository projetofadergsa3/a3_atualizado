<?php

class Usuario{

public $idUsuario, $idPerfil,$nomeUsuario, $emailUsuario, 
 $loginUsuario, $senhaUsuario, $telefoneCelular, $ativo;

    public function __construct($idUsuario = NULL, $idPerfil = NULL, $nomeUsuario = NULL, $emailUsuario = NULL, 
    $loginUsuario = NULL, $senhaUsuario = NULL, $telefoneCelular = NULL, $ativo = NULL){

        $this->idUsuario = $idUsuario;
        $this->idPerfil = $idPerfil;
        $this->nomeUsuario = $nomeUsuario;
        $this->emailUsuario = $emailUsuario;
        $this->loginUsuario = $loginUsuario; 
        $this->senhaUsuario = $senhaUsuario;
        $this->telefoneCelular = $telefoneCelular; 
        $this->ativo = $ativo;             
    }
}
