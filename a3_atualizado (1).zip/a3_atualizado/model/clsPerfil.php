<?php

class Perfil{

    public $idPerfil, $nomePerfil, $dataCadastro, $ativo;

    public function __construct($idPerfil = NULL, $nomePerfil = NULL, $dataCadastro = NULL, $ativo = NULL){
    $this->idPerfil = $idPerfil;
    $this->nomePerfil = $nomePerfil;
    $this->dataCadastro = $dataCadastro;
    $this->ativo = $ativo;
    }
}