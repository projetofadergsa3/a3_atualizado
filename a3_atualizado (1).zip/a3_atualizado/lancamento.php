<?php
session_start();
include_once("model/clsLancamento.php");
include_once("dao/clsLancamentoDAO.php");

include_once("model/clsDespesa.php");
include_once("dao/clsDespesaDAO.php");

include_once("dao/clsConexao.php");

include_once("dao/clsUsuarioDAO.php");
include_once("model/clsUsuario.php");

include_once("dao/clsBaseDAO.php");
include_once("model/clsBase.php");



/*if( !isset($_SESSION["logado"]) || $_SESSION["logado"] == false ){
    header("Location: index.php");
}else{
*/
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lançamento</title>
</head>

<body>
<a href="sessao.php">
    <button>Voltar ao início</button></a>
    <h1>Lançamento de Despesas</h1>

    <form method="POST" action="controller/salvarLancamento.php?inserir">
    <label for="nome" class="form-label">Valor Líquido</label>
            <input class="form-control" type="text" name="txtValorLiquido" id="valorLiquido" required>
            <br>
            <label for="nome" class="form-label">Valor Multa</label>
            <input class="form-control" type="text" name="txtValorMulta" id="valorMulta" required>
            <br>
            <label for="nome" class="form-label">Valor Juros</label>
            <input class="form-control" type="text" name="txtValorJuros" id="valorJuros" required>
            <br>
            <label for="nome" class="form-label">Valor Correcao</label>
            <input class="form-control" type="text" name="txtValorCorrecao" id="valorCorrecao" required>
            <br>
            <label for="nome" class="form-label">Competência da Despesa</label>
            <input class="form-control" type="text" name="txtCompetencia" id="competenciaDespesa" required>
            <br>
            <label for="nome" class="form-label">Data de Vencimento</label>
            <input class="form-control" type="date" name="txtDataVencimento" id="valorVencimento" required>

            <br><br>
    <select name="txtBase" required>
            <option value="">Selecione a base física... </option>
                <br><br>
                <?php
                    $bases = BaseDAO::getBases();
                    foreach($bases as $bas) {
                        echo '<option value="'.$bas->idBase.'">'.$bas->nomeBase.'</option>';
                    }
                ?>
                <br><br>
            </select>
                <br><br>
                <select name="txtDespesa" required>
                <option value="">Selecione a despesa... </option>
                <?php
                    $despesa = DespesaDAO::getDespesas();
                    
                    foreach($despesa as $des) {
                        echo '<option value="'.$des->idDespesa.'">'.$des->nomeDespesa. ' - ' . $des->idCredor->nomeCredor.'</option>';
                    }
                ?>
                <br><br>
            </select>
                <br><br>
    <select name="txtUsuario" required>
                <option value="">Selecione o Usuário que fez o lançamento... </option>
                <?php
                    $usuario = UsuarioDAO::getUsuario();
                    foreach($usuario as $usu) {
                        echo '<option value="'.$usu->idUsuario.'">'.$usu->nomeUsuario.'</option>';
                    }
                ?>
                <br><br>
            </select>
                <br><br>
            <label>Observação: </label>
        <textarea rows="5" cols="40" name="txtObservacao"></textarea>
        <br><br>
            <input type="submit" value="Cadastrar Lançamento" class="btn btn-success mt-2">
            <input type="reset" value="Limpar" class="btn btn-success mt-2">

            
    </form>
    <hr>
    

    <?php
    $lancamentos = LancamentoDAO::getLancamento();

    if( count($lancamentos) == 0 ){
        echo "<h1>Nenhum lançamento feito!!</h1>";
    }else{
?>
    <table border="1">
        <tr>
            <th>Id</th>
            <th>Credor</th>
            <th>Base física</th>
            <th>Despesa</th>
            <th>Vencimento</th>
            <th>Valor Total </th>
            <th>Multa</th>
            <th>Juros</th>
            <th>Correção</th>
            <th>Valor Líquido</th>
            <th>Observação</th>
            <th>Editar</th>
            <th>Excluir</th>
        </tr>
        <?php
            foreach($lancamentos as $lanca){
                $idLancamento= $lanca->idLancamento;
                $dataVencimento= $lanca->dataVencimento;
                $valorMulta = floatval($lanca->valorMulta);
                $valorCorrecao = floatval($lanca->valorCorrecao);
                $valorLiquido = floatval($lanca->valorLiquido);
                $valorJuros = floatval($lanca->valorJuros);

                $valorTotal = $valorLiquido + $valorCorrecao + $valorMulta + $valorJuros;
                

            
                echo "  <tr>
                            <td>$idLancamento</td>
                            <td>".$lanca->idDespesa->idCredor->nomeCredor."</td>
                            <td>".$lanca->idBase->nomeBase."</td>
                            <td>".$lanca->idDespesa->nomeDespesa."</td>
                            <td>".$lanca->dataVencimento."</td>
                            
                            <td>".$valorTotal."</td>
                            <td>".$lanca->valorMulta."</td>
                            <td>".$lanca->valorJuros."</td>
                            <td>".$lanca->valorCorrecao."</td>
                            <td>".$lanca->valorLiquido."</td>
                            <td>".$lanca->observacao."</td>


                            <td><a href='editarLancamento.php?id=$idLancamento'><button>Editar</button></a></td>
                        
                        <td><a onclick='return confirm(\"Você tem certeza que deseja apagar?\")'
                        href='controller/salvarLancamento.php?excluir&id=$idLancamento'>
                                <button>Excluir</button></a></td>
                        </tr>";
        }
        
        ?>
    </table>



    <?php

        }

        if( isset($_REQUEST["lancamentoExcluido"])){
            echo "<script> alert('Lançamento excluído com sucesso!'); </script>";
        }

        if( isset($_REQUEST["nome"])){
            $nome = $_REQUEST["nome"];
            echo "<script> alert('Lançamento cadastrado com sucesso!'); </script>";
        }
    ?>

</script>
</body>

</html>
