<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EDITAR USUÁRIO</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    <script>
        $(document).ready(function() {
            // Aplicar a máscara ao campo de celular
            $('input[name="txtCelular"]').mask('00 00000-0000');
        });
    </script>
</head>

<body>
    <br>

    <?php 
    $idUsuario= $_GET['id'];
    

    include_once ("dao/clsConexao.php");

    include_once("model/clsPerfil.php");
    include_once ("dao/clsPerfilDAO.php");
    
    include_once ("model/clsUsuario.php");
    include_once ("dao/clsUsuarioDAO.php");


    $idUsu = UsuarioDAO::getUsuarioById($idUsuario);

    $idPerf = UsuarioDAO::getPerfilByIdUsuario($idUsuario);
    
    ?>

    <h1>Editar Usuário:</h1>
    <form method="POST" action="controller/salvarUsuario.php?editar&id=<?=$idUsuario ?>">
        <label>Nome: </label>
        <input type="text" value="<?=$idUsu->nomeUsuario ?>" name="txtNome" required/>
        <br><br>
        <label>Login: </label>
        <input type="text" value="<?=$idUsu->loginUsuario ?>" name="txtLogin" required/>
        <br><br>
        <label>Senha: </label>
        <input type="text" value="<?=$idUsu->senhaUsuario ?>" name="txtSenha" required/>
        <br><br>
        <label>Celular: </label>
        <input type="text" value="<?=$idUsu->telefoneCelular ?>" name="txtCelular" required/>
        <br><br>
        <label>E-mail: </label>
        <input type="email" value="<?=$idUsu->emailUsuario ?>" name="txtEmail" required/>
        <br><br>
        <label>Perfil:</label>
        <select name="txtPerfil" required>
            <option value="">Selecione...  </option>
            <?php
                $perfil = PerfilDAO::getPerfil();
                foreach($perfil as $lista){
                    echo '<option value="'.$lista->idPerfil.'">'. $lista->nomePerfil.'</option>';
                }
            ?>

        </select>
        <br><br>

        <input type="submit" value="Salvar alterações" />
    </form>
    <br>
    <hr>

</body>

</html>
