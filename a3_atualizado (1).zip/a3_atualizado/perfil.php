<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfis</title>
</head>

<body>
<a href="sessao.php">
<button>Voltar ao início</button></a>
    <h1>Cadastro de Perfil</h1>
    <form method="POST" action="controller/salvarPerfil.php?inserir">
    <label for="nome" class="form-label">Nome do Perfil:</label>
            <input class="form-control" type="text" name="txtNome" id="nome" required>
            <br>
            <input type="submit" value="Cadastrar Perfil" class="btn btn-success mt-2">
    </form>


    <?php
    include_once("model/clsPerfil.php");
    include_once("dao/clsPerfilDAO.php");
    include_once("dao/clsConexao.php");

    

    $perfil = PerfilDAO::getPerfil();

    if( count($perfil) == 0 ){
        echo "<h1>Nenhum Perfil cadastrado!</h1>";
    }else{
?>
    <table border="1">
        <tr>
            <th>Id</th>
            <th>Nome</th>
            <th>Editar</th>
            <th>Excluir</th>
        </tr>

        <?php
            
            foreach($perfil as $per){
                $id= $per->idPerfil;
                $nome=$per->nomePerfil;
                echo "  <tr>
                            <td>$id</td>
                            <td>$nome</td>
                            <td><a href='editarPerfil.php?id=$id'><button>Editar</button></a></td>
                        
                        <td><a onclick='return confirm(\"Você tem certeza que deseja apagar?\")'
                        href='controller/salvarPerfil.php?excluir&id=$id'>
                                <button>Excluir</button></a></td>
                        </tr>";
        }
        
                

    
       /*     if( isset($_REQUEST["nome"])){
                $nome = $_REQUEST["nome"];
                echo "  <tr>
                            <td>3</td>
                            <td>$nome</td>
                            <td><button>Editar</button></td>
                            <td><button>Excluir</button></td>
                        </tr>";
            }
            */
        ?>
    </table>



    <?php

        }

        if( isset($_REQUEST["perfilExcluido"])){
            echo "<script> alert('Perfil excluído com sucesso!'); </script>";
        }

        if( isset($_REQUEST["nome"])){
            $nome = $_REQUEST["nome"];
            echo "<script> alert('Perfil $nome cadastrado com sucesso!'); </script>";
        }
    ?>
</body>

</html>
