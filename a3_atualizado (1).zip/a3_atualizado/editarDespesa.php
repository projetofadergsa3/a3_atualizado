<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EDITAR DESPESA</title>
</head>

<body>
    <br>

    <?php 
    $id= $_GET['id'];
    
 
    include_once ("dao/clsConexao.php");
  
    include_once ("model/clsDespesa.php");
    include_once ("dao/clsDespesaDAO.php");

    include_once ("dao/clsUsuarioDAO.php");
    include_once ("model/clsUsuario.php");

    include_once("dao/clsCredorDAO.php");
    include_once("model/clsCredor.php");

    $despesa = DespesaDAO::getDespesaById($id);
    
    ?>

    <h1>Editar Despesa:</h1>
    <form method="POST" action="controller/salvarDespesa.php?editar&id=<?=$id ?>">
        <label>Nome: </label>
        <input type="text" value="<?=$despesa->nomeDespesa ?>" name="txtNome" required/>
        <br><br>
        <select name="txtUsuario" required>
                <option value="">Selecione o Usuário que cadastrou </option>
                <?php
                    $usuario = UsuarioDAO::getUsuario();
                    foreach($usuario as $usu) {
                        echo '<option value="'.$usu->idUsuario.'">'.$usu->nomeUsuario.'</option>';
                    }
                ?>
            </select>
            <br>
            <select name="txtCredor" required>
                <option value="">Selecione o Credor da Despesa </option>
                <?php
                    $credor = CredorDAO::getCredor();
                    foreach($credor as $cre) {
                        echo '<option value="'.$cre->idCredor.'">'.$cre->nomeCredor.'</option>';
                    }
                ?>
            </select>
        <input type="submit" value="Salvar alterações" />
    </form>
    <br>
    <hr>

</body>

</html>