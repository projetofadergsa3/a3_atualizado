<?php
session_start();

if( !isset($_SESSION["logado"]) || $_SESSION["logado"] == false ){
    header("Location: index.php");
}else{
    include_once("model/clsLancamento.php");
    include_once("dao/clsLancamentoDAO.php");
    
    include_once("model/clsDespesa.php");
    include_once("dao/clsDespesaDAO.php");
    
    include_once("dao/clsConexao.php");
    
    include_once("dao/clsUsuarioDAO.php");
    include_once("model/clsUsuario.php");
    
    include_once("dao/clsBaseDAO.php");
    include_once("model/clsBase.php");

    include_once("dao/clsCredorDAO.php");
    include_once("model/clsCredor.php");

	require_once("fpdf/fpdf.php");

	define ('FPDF_FONTPATH','fpdf/font/');
	$pdf = new FPDF("P", "mm", "A4");
	$pdf->SetFont("arial","", 10 );
	$pdf->SetTextColor(0,0,0);
	$pdf->SetY("-1");
	$pdf->Cell(0,0,'',0,1,'L'); 

	if(isset($_POST["txtBase"])){
	$idBase = $_POST['txtBase'];
    $lancamentos = LancamentoDAO::getLancamentoByIdBase($idBase);
	if( count($lancamentos) == 0){

		$pdf->SetX(40);
		$pdf->SetY(100);
		$pdf->MultiCell(180, 10, ("Nenhum Lançamento Cadastrado!"), 2, "C",);
	}else{
		$pdf->SetFont('Arial','B',8);
		$pdf->SetY("30");
            	$pdf->SetX("10");
            	$pdf->Cell(10,10,utf8_decode('Id'), 1, 1, "C");

            	$pdf->SetY("30");
            	$pdf->SetX("20");
            	$pdf->Cell(20,10,utf8_decode('Credor'),1,1,'L'); 

				$pdf->SetY("30");
            	$pdf->SetX("40");
				$pdf->Cell(20,10,utf8_decode('Base'), 1, 1, "S");

				$pdf->SetY("30");
            	$pdf->SetX("60");
				$pdf->Cell(20,10,utf8_decode('Despesa'), 1, 1, "N");

                $pdf->SetY("30");
            	$pdf->SetX("80");
				$pdf->Cell(20,10,utf8_decode('Vencimento'), 1, 1, "C");

                $pdf->SetY("30");
            	$pdf->SetX("100");
				$pdf->Cell(20,10,utf8_decode('Total'), 1, 1, "C");

                $pdf->SetY("30");
            	$pdf->SetX("120");
				$pdf->Cell(20,10,utf8_decode('Multa'), 1, 1, "C");

                $pdf->SetY("30");
            	$pdf->SetX("140");
				$pdf->Cell(20,10,utf8_decode('Juros'), 1, 1, "C");

                $pdf->SetY("30");
            	$pdf->SetX("160");
				$pdf->Cell(20,10,utf8_decode('Correção'), 1, 1, "C");

                $pdf->SetY("30");
            	$pdf->SetX("180");
				$pdf->Cell(20,10,utf8_decode('Vlíquido'), 1, 1, "C");



		$pdf->SetFont('Arial','I',8);	
		$pdf->SetTextColor(0,0,0);
		$y = 40;

		foreach($lancamentos as $lanc){

            $valorTotal = $lanc->valorLiquido + $lanc->valorCorrecao + $lanc->valorMulta + $lanc->valorJuros;

			$pdf->SetY($y);
			$pdf->SetX("10");
			$pdf->Cell(10,10, utf8_decode($lanc->idLancamento), 1, 1, "C");

			$pdf->SetY($y);
			$pdf->SetX("20");
			$pdf->Cell(20,10,utf8_decode($lanc->idDespesa->idCredor->nomeCredor),1,1,'L'); 

			$pdf->SetY($y);
			$pdf->SetX("40");
			$pdf->Cell(20,10,utf8_decode($lanc->idBase->nomeBase),1,1,'S');

			$pdf->SetY($y);
			$pdf->SetX("60");
			$pdf->Cell(20,10,utf8_decode($lanc->idDespesa->nomeDespesa),1,1,'N');

            $pdf->SetY($y);
			$pdf->SetX("80");
			$pdf->Cell(20,10,utf8_decode($lanc->dataVencimento),1,1,'N');

            $pdf->SetY($y);
			$pdf->SetX("100");
			$pdf->Cell(20,10,'R$ ' .utf8_decode($valorTotal),1,1,'N');

            $pdf->SetY($y);
			$pdf->SetX("120");
			$pdf->Cell(20,10,'R$ ' .utf8_decode($lanc->valorMulta),1,1,'N');

            $pdf->SetY($y);
			$pdf->SetX("140");
			$pdf->Cell(20,10,'R$ ' .utf8_decode($lanc->valorJuros),1,1,'N');

            $pdf->SetY($y);
			$pdf->SetX("160");
			$pdf->Cell(20,10,'R$ ' .utf8_decode($lanc->valorCorrecao),1,1,'N');

            $pdf->SetY($y);
			$pdf->SetX("180");
			$pdf->Cell(20,10,'R$ ' .utf8_decode($lanc->valorLiquido),1,1,'N');


			$y += 10;
		}
	}
	$pdf->Output("relatorio.pdf", "I");
	}
	
	if (isset($_POST["txtDespesa"])){
	$idDespesa = $_POST['txtDespesa'];
    $lancamentos = LancamentoDAO::getLancamentoByIdDespesa($idDespesa);
	if( count($lancamentos) == 0){

		$pdf->SetX(40);
		$pdf->SetY(100);
		$pdf->MultiCell(180, 10, ("Nenhum Lançamento Cadastrado!"), 2, "C",);
	}else{
		$pdf->SetFont('Arial','B',8);
		$pdf->SetY("30");
            	$pdf->SetX("10");
            	$pdf->Cell(10,10,utf8_decode('Id'), 1, 1, "C");

            	$pdf->SetY("30");
            	$pdf->SetX("20");
            	$pdf->Cell(20,10,utf8_decode('Credor'),1,1,'L'); 

				$pdf->SetY("30");
            	$pdf->SetX("40");
				$pdf->Cell(20,10,utf8_decode('Base'), 1, 1, "S");

				$pdf->SetY("30");
            	$pdf->SetX("60");
				$pdf->Cell(20,10,utf8_decode('Despesa'), 1, 1, "N");

                $pdf->SetY("30");
            	$pdf->SetX("80");
				$pdf->Cell(20,10,utf8_decode('Vencimento'), 1, 1, "C");

                $pdf->SetY("30");
            	$pdf->SetX("100");
				$pdf->Cell(20,10,utf8_decode('Total'), 1, 1, "C");

                $pdf->SetY("30");
            	$pdf->SetX("120");
				$pdf->Cell(20,10,utf8_decode('Multa'), 1, 1, "C");

                $pdf->SetY("30");
            	$pdf->SetX("140");
				$pdf->Cell(20,10,utf8_decode('Juros'), 1, 1, "C");

                $pdf->SetY("30");
            	$pdf->SetX("160");
				$pdf->Cell(20,10,utf8_decode('Correção'), 1, 1, "C");

                $pdf->SetY("30");
            	$pdf->SetX("180");
				$pdf->Cell(20,10,utf8_decode('Vlíquido'), 1, 1, "C");



		$pdf->SetFont('Arial','I',8);	
		$pdf->SetTextColor(0,0,0);
		$y = 40;

		foreach($lancamentos as $lanc){

            $valorTotal = $lanc->valorLiquido + $lanc->valorCorrecao + $lanc->valorMulta + $lanc->valorJuros;

			$pdf->SetY($y);
			$pdf->SetX("10");
			$pdf->Cell(10,10, utf8_decode($lanc->idLancamento), 1, 1, "C");

			$pdf->SetY($y);
			$pdf->SetX("20");
			$pdf->Cell(20,10,utf8_decode($lanc->idDespesa->idCredor->nomeCredor),1,1,'L'); 

			$pdf->SetY($y);
			$pdf->SetX("40");
			$pdf->Cell(20,10,utf8_decode($lanc->idBase->nomeBase),1,1,'S');

			$pdf->SetY($y);
			$pdf->SetX("60");
			$pdf->Cell(20,10,utf8_decode($lanc->idDespesa->nomeDespesa),1,1,'N');

            $pdf->SetY($y);
			$pdf->SetX("80");
			$pdf->Cell(20,10,utf8_decode($lanc->dataVencimento),1,1,'N');

            $pdf->SetY($y);
			$pdf->SetX("100");
			$pdf->Cell(20,10,'R$ ' .utf8_decode($valorTotal),1,1,'N');

            $pdf->SetY($y);
			$pdf->SetX("120");
			$pdf->Cell(20,10,'R$ ' .utf8_decode($lanc->valorMulta),1,1,'N');

            $pdf->SetY($y);
			$pdf->SetX("140");
			$pdf->Cell(20,10,'R$ ' .utf8_decode($lanc->valorJuros),1,1,'N');

            $pdf->SetY($y);
			$pdf->SetX("160");
			$pdf->Cell(20,10,'R$ ' .utf8_decode($lanc->valorCorrecao),1,1,'N');

            $pdf->SetY($y);
			$pdf->SetX("180");
			$pdf->Cell(20,10,'R$ ' .utf8_decode($lanc->valorLiquido),1,1,'N');


			$y += 10;
		}
	}
	$pdf->Output("relatorio.pdf", "I");
	}
	if (isset($_POST["txtCredor"])){
		$idCredor = $_POST['txtCredor'];
		$lancamentos = LancamentoDAO::getLancamentoByIdCredor($idCredor);
		if( count($lancamentos) == 0){
	
			$pdf->SetX(40);
			$pdf->SetY(100);
			$pdf->MultiCell(180, 10, ("Nenhum Lançamento Cadastrado!"), 2, "C",);
		}else{
			$pdf->SetFont('Arial','B',8);
			$pdf->SetY("30");
					$pdf->SetX("10");
					$pdf->Cell(10,10,utf8_decode('Id'), 1, 1, "C");
	
					$pdf->SetY("30");
					$pdf->SetX("20");
					$pdf->Cell(20,10,utf8_decode('Credor'),1,1,'L'); 
	
					$pdf->SetY("30");
					$pdf->SetX("40");
					$pdf->Cell(20,10,utf8_decode('Base'), 1, 1, "S");
	
					$pdf->SetY("30");
					$pdf->SetX("60");
					$pdf->Cell(20,10,utf8_decode('Despesa'), 1, 1, "N");
	
					$pdf->SetY("30");
					$pdf->SetX("80");
					$pdf->Cell(20,10,utf8_decode('Vencimento'), 1, 1, "C");
	
					$pdf->SetY("30");
					$pdf->SetX("100");
					$pdf->Cell(20,10,utf8_decode('Total'), 1, 1, "C");
	
					$pdf->SetY("30");
					$pdf->SetX("120");
					$pdf->Cell(20,10,utf8_decode('Multa'), 1, 1, "C");
	
					$pdf->SetY("30");
					$pdf->SetX("140");
					$pdf->Cell(20,10,utf8_decode('Juros'), 1, 1, "C");
	
					$pdf->SetY("30");
					$pdf->SetX("160");
					$pdf->Cell(20,10,utf8_decode('Correção'), 1, 1, "C");
	
					$pdf->SetY("30");
					$pdf->SetX("180");
					$pdf->Cell(20,10,utf8_decode('Vlíquido'), 1, 1, "C");
	
	
	
			$pdf->SetFont('Arial','I',8);	
			$pdf->SetTextColor(0,0,0);
			$y = 40;
	
			foreach($lancamentos as $lanc){
	
	
				$valorTotal = $lanc->valorLiquido + $lanc->valorCorrecao + $lanc->valorMulta + $lanc->valorJuros;
	
				$pdf->SetY($y);
				$pdf->SetX("10");
				$pdf->Cell(10,10, utf8_decode($lanc->idLancamento), 1, 1, "C");
	
				$pdf->SetY($y);
				$pdf->SetX("20");
				$pdf->Cell(20,10,utf8_decode($lanc->idDespesa->idCredor->nomeCredor),1,1,'L'); 
	
				$pdf->SetY($y);
				$pdf->SetX("40");
				$pdf->Cell(20,10,utf8_decode($lanc->idBase->nomeBase),1,1,'S');
	
				$pdf->SetY($y);
				$pdf->SetX("60");
				$pdf->Cell(20,10,utf8_decode($lanc->idDespesa->nomeDespesa),1,1,'N');
	
				$pdf->SetY($y);
				$pdf->SetX("80");
				$pdf->Cell(20,10,utf8_decode($lanc->dataVencimento),1,1,'N');
	
				$pdf->SetY($y);
				$pdf->SetX("100");
				$pdf->Cell(20,10,'R$ ' .utf8_decode($valorTotal),1,1,'N');
	
				$pdf->SetY($y);
				$pdf->SetX("120");
				$pdf->Cell(20,10,'R$ ' .utf8_decode($lanc->valorMulta),1,1,'N');
	
				$pdf->SetY($y);
				$pdf->SetX("140");
				$pdf->Cell(20,10,'R$ ' .utf8_decode($lanc->valorJuros),1,1,'N');
	
				$pdf->SetY($y);
				$pdf->SetX("160");
				$pdf->Cell(20,10,'R$ ' .utf8_decode($lanc->valorCorrecao),1,1,'N');
	
				$pdf->SetY($y);
				$pdf->SetX("180");
				$pdf->Cell(20,10,'R$ ' .utf8_decode($lanc->valorLiquido),1,1,'N');
	
	
				$y += 10;
			}
		}
		$pdf->Output("relatorio.pdf", "I");
		}
		if (isset($_POST["dataInicio"]) && ($_POST["dataFim"])){
			$inicio = $_POST['dataInicio'];
			$fim = $_POST['dataFim'];
			$lancamentos = LancamentoDAO::getLancamentoByData($inicio, $fim);
			if( count($lancamentos) == 0){
		
				$pdf->SetX(40);
				$pdf->SetY(100);
				$pdf->MultiCell(180, 10, ("Nenhum Lançamento Cadastrado!"), 2, "C",);
			}else{
				$pdf->SetFont('Arial','B',8);
				$pdf->SetY("30");
						$pdf->SetX("10");
						$pdf->Cell(10,10,utf8_decode('Id'), 1, 1, "C");
		
						$pdf->SetY("30");
						$pdf->SetX("20");
						$pdf->Cell(20,10,utf8_decode('Credor'),1,1,'L'); 
		
						$pdf->SetY("30");
						$pdf->SetX("40");
						$pdf->Cell(20,10,utf8_decode('Base'), 1, 1, "S");
		
						$pdf->SetY("30");
						$pdf->SetX("60");
						$pdf->Cell(20,10,utf8_decode('Despesa'), 1, 1, "N");
		
						$pdf->SetY("30");
						$pdf->SetX("80");
						$pdf->Cell(20,10,utf8_decode('Vencimento'), 1, 1, "C");
		
						$pdf->SetY("30");
						$pdf->SetX("100");
						$pdf->Cell(20,10,utf8_decode('Total'), 1, 1, "C");
		
						$pdf->SetY("30");
						$pdf->SetX("120");
						$pdf->Cell(20,10,utf8_decode('Multa'), 1, 1, "C");
		
						$pdf->SetY("30");
						$pdf->SetX("140");
						$pdf->Cell(20,10,utf8_decode('Juros'), 1, 1, "C");
		
						$pdf->SetY("30");
						$pdf->SetX("160");
						$pdf->Cell(20,10,utf8_decode('Correção'), 1, 1, "C");
		
						$pdf->SetY("30");
						$pdf->SetX("180");
						$pdf->Cell(20,10,utf8_decode('Vlíquido'), 1, 1, "C");
		
		
		
				$pdf->SetFont('Arial','I',8);	
				$pdf->SetTextColor(0,0,0);
				$y = 40;
		
				foreach($lancamentos as $lanc){
		
					$valorTotal = $lanc->valorLiquido + $lanc->valorCorrecao + $lanc->valorMulta + $lanc->valorJuros;
		
					$pdf->SetY($y);
					$pdf->SetX("10");
					$pdf->Cell(10,10, utf8_decode($lanc->idLancamento), 1, 1, "C");
		
					$pdf->SetY($y);
					$pdf->SetX("20");
					$pdf->Cell(20,10,utf8_decode($lanc->idDespesa->idCredor->nomeCredor),1,1,'L'); 
		
					$pdf->SetY($y);
					$pdf->SetX("40");
					$pdf->Cell(20,10,utf8_decode($lanc->idBase->nomeBase),1,1,'S');
		
					$pdf->SetY($y);
					$pdf->SetX("60");
					$pdf->Cell(20,10,utf8_decode($lanc->idDespesa->nomeDespesa),1,1,'N');
		
					$pdf->SetY($y);
					$pdf->SetX("80");
					$pdf->Cell(20,10,utf8_decode($lanc->dataVencimento),1,1,'N');
		
					$pdf->SetY($y);
					$pdf->SetX("100");
					$pdf->Cell(20,10,'R$ ' . utf8_decode($valorTotal),1,1,'N');
		
					$pdf->SetY($y);
					$pdf->SetX("120");
					$pdf->Cell(20,10,'R$ ' .utf8_decode($lanc->valorMulta),1,1,'N');
		
					$pdf->SetY($y);
					$pdf->SetX("140");
					$pdf->Cell(20,10,'R$ ' .utf8_decode($lanc->valorJuros),1,1,'N');
		
					$pdf->SetY($y);
					$pdf->SetX("160");
					$pdf->Cell(20,10,'R$ ' .utf8_decode($lanc->valorCorrecao),1,1,'N');
		
					$pdf->SetY($y);
					$pdf->SetX("180");
					$pdf->Cell(20,10,'R$ ' .utf8_decode($lanc->valorLiquido),1,1,'N');
		
		
					$y += 10;
				}
			}
			$pdf->Output("relatorio.pdf", "I");
			}
		}
?>  