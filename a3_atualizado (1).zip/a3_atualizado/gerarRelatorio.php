<?php
session_start();
include_once("model/clsLancamento.php");
include_once("dao/clsLancamentoDAO.php");

include_once("model/clsDespesa.php");
include_once("dao/clsDespesaDAO.php");

include_once("dao/clsConexao.php");

include_once("dao/clsUsuarioDAO.php");
include_once("model/clsUsuario.php");

include_once("dao/clsBaseDAO.php");
include_once("model/clsBase.php");

include_once("dao/clsCredorDAO.php");
include_once("model/clsCredor.php");



if( !isset($_SESSION["logado"]) || $_SESSION["logado"] == false ){
    header("Location: index.php");
}else{

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Relatórios</title>
</head>

<body>
    <a href="sessao.php"><button>Voltar ao início</button></a>
    <h1>Gerar Relatórios</h1>

    <h2>Relatório por Base física</h2>
<form id="formBase" method="POST" action="relatorio.php" onsubmit="return validarForm('txtBase') && validarFormato('formBase')">
    <select name="txtBase">
        <option value="">Selecione a base física... </option>
        <?php
        $bases = BaseDAO::getBases();
        foreach ($bases as $bas) {
            echo '<option value="'.$bas->idBase.'">'.$bas->nomeBase.'</option>';
        }
        ?>
    </select>
    <br><br>
    <input type="radio" name="formato" value="csv" id="csvBase">
    <label for="csvBase">CSV</label><br>
    <input type="radio" name="formato" value="pdf" id="pdfBase">
    <label for="pdfBase">FPDF</label><br><br>
    <input type="submit" value="Gerar Relatório">
    <br><hr>
</form>

<script>
    function validarFormato(formId) {
        var formato = document.querySelector('#' + formId + ' input[name="formato"]:checked');
        if (formato) {
            if (formato.value === 'csv') {
                document.getElementById(formId).action = 'relatoriocsv.php';
            } else if (formato.value === 'pdf') {
                document.getElementById(formId).action = 'relatorio.php';
            }
            return true;
        }
        return false;
    }
</script>


    <h2>Relatório por Credor</h2>
<form id="formCredor" method="POST" action="relatorio.php" onsubmit="return validarForm('txtCredor') && validarFormato('formCredor')">
    <select name="txtCredor">
        <option value="">Selecione o Credor... </option>
        <?php
        $credores = CredorDAO::getCredor();
        foreach ($credores as $cre) {
            echo '<option value="'.$cre->idCredor.'">'.$cre->nomeCredor.'</option>';
        }
        ?>
    </select>
    <br><br>
    <input type="radio" name="formato" value="csv" id="csvCredor">
    <label for="csvCredor">CSV</label><br>
    <input type="radio" name="formato" value="pdf" id="pdfCredor">
    <label for="pdfCredor">FPDF</label><br><br>
    <input type="submit" value="Gerar Relatório">
    <br><hr>
</form>

<script>
    function validarFormato(formId) {
        var formato = document.querySelector('#' + formId + ' input[name="formato"]:checked');
        if (formato) {
            if (formato.value === 'csv') {
                document.getElementById(formId).action = 'relatoriocsv.php';
            } else if (formato.value === 'pdf') {
                document.getElementById(formId).action = 'relatorio.php';
            }
            return true;
        }
        return false;
    }
</script>

    
    <h2>Relatório por Despesa</h2>
<form id="formDespesa" method="POST" action="relatorio.php" onsubmit="return validarForm('txtDespesa') && validarFormato('formDespesa')">
    <select name="txtDespesa">
        <option value="">Selecione a Despesa... </option>
        <?php
        $despesas = DespesaDAO::getDespesas();
        foreach ($despesas as $des) {
            echo '<option value="'.$des->idDespesa.'">'.$des->nomeDespesa.'</option>';
        }
        ?>
    </select>
    <br><br>
    <input type="radio" name="formato" value="csv" id="csvDespesa">
    <label for="csvDespesa">CSV</label><br>
    <input type="radio" name="formato" value="pdf" id="pdfDespesa">
    <label for="pdfDespesa">FPDF</label><br><br>
    <input type="submit" value="Gerar Relatório" />
</form>

<script>
    function validarFormato(formId) {
        var formato = document.querySelector('#' + formId + ' input[name="formato"]:checked');
        if (formato) {
            if (formato.value === 'csv') {
                document.getElementById(formId).action = 'relatoriocsv.php';
            } else if (formato.value === 'pdf') {
                document.getElementById(formId).action = 'relatorio.php';
            }
            return true;
        }
        return false;
    }
</script>


<h2>Relatório por intervalo de tempo</h2>
<form id="formIntervalo" method="POST" action="relatorio.php" onsubmit="return validarFormato('formIntervalo')">
        <label for="dataInicio">Data Início:</label>
        <input type="date" id="dataInicio" name="dataInicio" required>
        
        <label for="dataFim">Data Fim:</label>
        <input type="date" id="dataFim" name="dataFim" required>
        <br><br>
        <input type="radio" name="formato" value="csv" id="csvIntervalo">
        <label for="csvIntervalo">CSV</label><br><br>
        
        <input type="radio" name="formato" value="pdf" id="pdfIntervalo">
        <label for="pdfIntervalo">FPDF</label><br><br>
        
        <input type="submit" value="Gerar Relatório" />
    </form>
    <hr>

    <script>
        function validarForm(elementName) {
            var selectElement = document.getElementsByName(elementName)[0];
            if (selectElement.value === "") {
                alert("Por favor, selecione uma opção válida.");
                return false;
            }
            return true;
        }

        function validarFormato(formId) {
            var formato = document.querySelector('#' + formId + ' input[name="formato"]:checked');
            if (formato) {
                if (formato.value === 'csv') {
                    document.getElementById(formId).action = 'relatoriocsv.php';
                } else if (formato.value === 'pdf') {
                    document.getElementById(formId).action = 'relatorio.php';
                }
                return true;
            }
            return false;
        }
        </script>
</body>

</html>
<?php
}
?>