<?php

$loginUsuario = $_POST["txtLogin"];
$senhaUsuario = $_POST["txtSenha"];



include_once("../model/clsUsuario.php");
include_once("../dao/clsUsuarioDAO.php");
include_once("../dao/clsConexao.php");


$user = UsuarioDAO::getUsuarioByLoginSenha($loginUsuario, $senhaUsuario );
if( !$user ) {
	header("Location: ../index.php?usuarioInvalido");
}else{
	session_start();
	$_SESSION['idUsuario'] = $user->idUsuario;
	$_SESSION["logado"] = true;
	$_SESSION["nomeUsuario"] = $user->nomeUsuario;
	$_SESSION["emailUsuario"] = $user->emailUsuario;
	header("Location: ../sessao.php");
}