<?php

include_once("../dao/clsConexao.php");

include_once("../dao/clsLancamentoDAO.php");
include_once("../model/clsLancamento.php");

//INSERIR USUARIO

if(isset($_REQUEST["inserir"])){
    $competenciaDespesa = $_POST["txtCompetencia"];
    $dataVencimento = $_POST["txtDataVencimento"];
    $valorLiquido = $_POST["txtValorLiquido"];
    $valorMulta = $_POST["txtValorMulta"];
    $valorJuros = $_POST["txtValorJuros"];
    $valorCorrecao = $_POST["txtValorCorrecao"];
    $observacao = $_POST["txtObservacao"];
    $idUsuario = $_POST["txtUsuario"];
    $idDespesa = $_POST["txtDespesa"];
    $idBase = $_POST["txtBase"];

    if(strlen($competenciaDespesa) == 0 ){
        header("Location: ../lancamento.php?competenciaVazia");
    }else{
        $lancamento = new Lancamento();
        $lancamento->competenciaDespesa = $competenciaDespesa;
        $lancamento->dataVencimento = $dataVencimento;
        $lancamento->valorLiquido = $valorLiquido;
        $lancamento->valorMulta = $valorMulta;
        $lancamento->valorJuros = $valorJuros;
        $lancamento->valorCorrecao = $valorCorrecao;
        $lancamento->observacao = $observacao;
        
        $lancamento->idDespesa = $idDespesa;
        $lancamento->idUsuario = $idUsuario;
        $lancamento->idBase = $idBase;

        LancamentoDAO:: inserir($lancamento);
        header("Location: ../lancamento.php?nome=$idLancamento");
    }
}

// EXCLUIR USUARIO

if(isset($_REQUEST["excluir"]) && isset($_REQUEST["id"])){
    $id = $_REQUEST["id"];
    LancamentoDAO:: excluir($id);
    header("Location: ../lancamento.php?lancamentoExcluido");
}


// EDITAR USUARIO

if( isset( $_REQUEST["editar"] ) &&  isset( $_REQUEST["id"] ) ){
    $id = $_REQUEST["id"];
    $competenciaDespesa = $_POST["txtCompetencia"];
    $dataVencimento = $_POST["txtDataVencimento"];
    $valorLiquido = $_POST["txtValorLiquido"];
    $valorMulta = $_POST["txtValorMulta"];
    $valorJuros = $_POST["txtValorJuros"];
    $valorCorrecao = $_POST["txtValorCorrecao"];
    $observacao = $_POST["txtObservacao"];
    $idUsuario = $_POST["txtUsuario"];
    $idDespesa = $_POST["txtDespesa"];
    $idBase = $_POST["txtBase"];
    LancamentoDAO::editar( $id, $idBase, $idUsuario, $idDespesa, $competenciaDespesa, $dataVencimento,
$valorLiquido, $valorMulta, $valorJuros, $valorCorrecao, $observacao);
    header( "Location: ../lancamento.php?LancamentoEditado");
}