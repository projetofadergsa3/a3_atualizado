<?php

include_once("../dao/clsConexao.php");

include_once("../dao/clsPerfilDAO.php");
include_once("../model/clsPerfil.php");

include_once("../dao/clsUsuarioDAO.php");
include_once("../model/clsUsuario.php");

//INSERIR USUARIO

if(isset($_REQUEST["inserir"])){
    $nome = $_POST["txtNome"];
    $email = $_POST["txtEmail"];
    $login = $_POST["txtLogin"];
    $senha = $_POST["txtSenha"];
    $celular = $_POST["txtCelular"];
    $idPerfil = $_POST["txtPerfil"];
    if(strlen($nome) == 0 ){
        header("Location: ../usuario.php?nomeVazio");
    }else{
        $perfil = new Perfil();
        $perfil->idPerfil = $_POST["txtPerfil"];

        $usuario = new Usuario();
        $usuario->nomeUsuario = $nome;
        $usuario->loginUsuario = $login;
        $usuario->emailUsuario = $email;
        $usuario->senhaUsuario = $senha;
        $usuario->telefoneCelular = $celular;
        $usuario->idPerfil = $idPerfil;
        UsuarioDAO::inserir($usuario);
        header("Location: ../usuario.php?nome=$nome");
    }
}

// EXCLUIR USUARIO

if(isset($_REQUEST["excluir"]) && isset($_REQUEST["id"])){
    $idUsuario = $_REQUEST["id"];
    UsuarioDAO:: excluir($idUsuario);
    header("Location: ../usuario.php?usuarioExcluido");
}


// EDITAR USUARIO

if( isset( $_REQUEST["editar"] ) &&  isset( $_REQUEST["id"] ) ){
    $id = $_REQUEST["id"];
    $nome = $_POST["txtNome"];
    $email = $_POST["txtEmail"];
    $login = $_POST["txtLogin"];
    $senha = $_POST["txtSenha"];
    $telefone = $_POST["txtCelular"];
    $idPerfil = $_POST["txtPerfil"];
    UsuarioDAO::editar( $id, $nome, $login, $email, $senha, $telefone, $idPerfil);
    header( "Location: ../usuario.php?usuarioEditado");
}