<?php

include_once("../dao/clsConexao.php");

include_once("../dao/clsCredorDAO.php");
include_once("../model/clsCredor.php");


//INSERIR USUARIO

if(isset($_REQUEST["inserir"])){
    $nome = $_POST["txtNome"];
    $responsavel = $_POST["txtResponsavel"];
    $telefone = $_POST["txtTelefone"];
    $celular = $_POST["txtCelular"];
    $idUsuario = $_POST["txtUsuario"];
    
    if(strlen($nome) == 0 ){
        header("Location: ../credor.php?nomeVazio");
    }elseif(strlen($responsavel) == 0 ){
            header("Location: ../credor.php?responsavelVazio");
    }elseif(strlen($telefone) == 0 ){
                header("Location: ../credor.php?telefoneVazio");
    }elseif(strlen($celular) == 0 ){
                    header("Location: ../credor.php?celularVazio");
    }else{
        $credor = new Credor();
        $credor->idCredor = $id;
        $credor->nomeCredor = $nome;
        $credor->responsavelCredor = $responsavel;
        $credor->telefoneCredor = $telefone;
        $credor->celularCredor = $celular;
        $credor->idUsuario = $idUsuario;
        CredorDAO:: inserir($credor);
        header("Location: ../credor.php?nome=$nome");
    }
}

// EXCLUIR USUARIO

if(isset($_REQUEST["excluir"]) && isset($_REQUEST["id"])){
    $id = $_REQUEST["id"];
    CredorDAO:: excluir($id);
    header("Location: ../credor.php?credorExcluido");
}


// EDITAR USUARIO

if( isset( $_REQUEST["editar"] ) &&  isset( $_REQUEST["id"] ) ){
    $id = $_REQUEST["id"];
    $nome = $_POST["txtNome"];
    $responsavel = $_POST["txtResponsavel"];
    $telefone = $_POST["txtTelefone"];
    $celular = $_POST["txtCelular"];
    $idUsuario = $_POST["txtUsuario"];
    CredorDAO::editar( $id, $nome, $responsavel, $telefone, $celular, $idUsuario);
    header( "Location: ../credor.php?credorEditado");
}