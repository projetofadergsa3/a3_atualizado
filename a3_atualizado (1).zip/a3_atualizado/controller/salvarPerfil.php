<?php

include_once("../dao/clsConexao.php");

include_once("../dao/clsPerfilDAO.php");
include_once("../model/clsPerfil.php");

//INSERIR USUARIO

if(isset($_REQUEST["inserir"])){
    $nome = $_POST["txtNome"];
    
    if(strlen($nome) == 0 ){
        header("Location: ../perfil.php?nomeVazio");
    }else{
        $perfil = new Perfil();
        $perfil->idPerfil = $id;
        $perfil->nomePerfil = $nome;
        PerfilDAO:: inserir($perfil);
        header("Location: ../perfil.php?nome=$nome");
    }
}

// EXCLUIR USUARIO

if(isset($_REQUEST["excluir"]) && isset($_REQUEST["id"])){
    $id = $_REQUEST["id"];
    PerfilDAO:: excluir($id);
    header("Location: ../perfil.php?perfilExcluido");
}

// EDITAR USUARIO

if( isset( $_REQUEST["editar"] ) &&  isset( $_REQUEST["id"] ) ){
    $nome = $_POST["txtNome"];  
    $id = $_REQUEST["id"];
    PerfilDAO::editar( $nome, $id);
    header( "Location: ../perfil.php?perfilEditado");
}