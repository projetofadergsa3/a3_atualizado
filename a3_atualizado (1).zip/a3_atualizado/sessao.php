<?php
session_start();

if( !isset($_SESSION["logado"]) || $_SESSION["logado"] == false ){
    header("Location: index.php");
}else{


?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projeto A3 - Página Administrativa</title>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-sm-6"><?php echo "<h3> Olá " . $_SESSION["nomeUsuario"] . "</h2> "; ?> </div> 
            <div class="col-sm-5"></div>
            <div class="col text-right">
            <a href="usuario.php">
            <button>Área de Usuário</button></a>
            <a href="perfil.php">
            <button>Perfil</button></a>
            <a href="credor.php">
            <button>Credor</button></a>
            <a href="base.php">
            <button>Base</button></a>
            <a href="despesa.php">
            <button>Despesa</button></a>
            <a href="lancamento.php">
            <button>Lançamento</button></a>
            <a href="gerarRelatorio.php">
            <button>Gerar Relatórios</button></a>
            <a href="controller/sair.php">
            <button>Sair</button></a>

            </div>
        </div>
</body>

</html>

<?php
}
?>

