<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EDITAR LANÇAMENTO</title>
</head>

<body>
    <br>

    <?php 
    $id= $_GET['id'];
    
    include_once("model/clsLancamento.php");
    include_once("dao/clsLancamentoDAO.php");
 
    include_once ("dao/clsConexao.php");
  
    include_once ("model/clsDespesa.php");
    include_once ("dao/clsDespesaDAO.php");

    include_once ("dao/clsUsuarioDAO.php");
    include_once ("model/clsUsuario.php");

    include_once("dao/clsBaseDAO.php");
    include_once("model/clsBase.php");

    $lancamento = LancamentoDAO::getLancamentoById($id);
    
    ?>

    <h1>Editar Lancamento:</h1>
    <form method="POST" action="controller/salvarLancamento.php?editar&id=<?=$id ?>">
    <label>Valor líquido: </label>
        <input type="text" value="<?=$lancamento->valorLiquido ?>" name="txtValorLiquido" required/>
        <br><br>
        <label>Valor multa: </label>
        <input type="text" value="<?=$lancamento->valorMulta ?>" name="txtValorMulta" required/>
        <br><br>
        <label>Valor juros: </label>
        <input type="text" value="<?=$lancamento->valorJuros ?>" name="txtValorJuros" required/>
        <br><br>
        <label>Valor correção: </label>
        <input type="text" value="<?=$lancamento->valorCorrecao ?>" name="txtValorCorrecao" required/>
        <br><br>
        <label>Competência despesa: </label>
        <input type="text" value="<?=$lancamento->competenciaDespesa ?>" name="txtCompetencia" required/>
        <br><br>
        <label>Data de Vencimento: </label>
        <input type="date" value="<?=$lancamento->dataVencimento ?>" name="txtDataVencimento" required/>
        <br><br>
    <select name="txtBase" required>
            <option value="">Selecione a base física... </option>
                <br><br>
                <?php
                    $bases = BaseDAO::getBases();
                    foreach($bases as $bas) {
                        echo '<option value="'.$bas->idBase.'">'.$bas->nomeBase.'</option>';
                    }
                ?>
                <br><br>
            </select>
                <br><br>
                <select name="txtDespesa" required>
                <option value="">Selecione a despesa... </option>
                <?php
                    $despesa = DespesaDAO::getDespesas();
                    foreach($despesa as $des) {
                        echo '<option value="'.$des->idDespesa.'">'.$des->nomeDespesa. ' - ' . $des->idCredor->nomeCredor.'</option>';
                    }
                ?>
                <br><br>
            </select>
                <br><br>
    <select name="txtUsuario" required>
                <option value="">Selecione o Usuário que fez o lançamento... </option>
                <?php
                    $usuario = UsuarioDAO::getUsuario();
                    foreach($usuario as $usu) {
                        echo '<option value="'.$usu->idUsuario.'">'.$usu->nomeUsuario.'</option>';
                    }
                ?>
                <br><br>
            </select>
                <br><br>
        <label>Observação: </label>
        <textarea rows="5" cols="40" name="txtObservacao"></textarea>
        <br><br>
            </select>
        <input type="submit" value="Salvar alterações" />
    </form>
</body>

</html>