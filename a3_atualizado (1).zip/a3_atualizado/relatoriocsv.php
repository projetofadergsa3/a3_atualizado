<?php
session_start();

if (!isset($_SESSION["logado"]) || $_SESSION["logado"] == false) {
    header("Location: index.php");
    exit;
}
include_once("model/clsLancamento.php");
include_once("dao/clsLancamentoDAO.php");
include_once("model/clsDespesa.php");
include_once("dao/clsDespesaDAO.php");
include_once("dao/clsConexao.php");
include_once("dao/clsUsuarioDAO.php");
include_once("model/clsUsuario.php");
include_once("dao/clsBaseDAO.php");
include_once("model/clsBase.php");
include_once("dao/clsCredorDAO.php");
include_once("model/clsCredor.php");

if (isset($_POST['txtCredor'])) {
    $idCredor = $_POST['txtCredor'];
    $lancamentos = LancamentoDAO::getLancamentoByIdCredor($idCredor);
    $tipoRelatorio = "Credor";
} elseif (isset($_POST['txtDespesa'])) {
    $idDespesa = $_POST['txtDespesa'];
    $lancamentos = LancamentoDAO::getLancamentoByIdDespesa($idDespesa);
    $tipoRelatorio = "Despesa";
} elseif (isset($_POST['txtBase'])) {
    $idBase = $_POST['txtBase'];
    $lancamentos = LancamentoDAO::getLancamentoByIdBase($idBase);
    $tipoRelatorio = "Base";
} elseif (isset($_POST["dataInicio"]) && ($_POST["dataFim"])) {
    $inicio = $_POST['dataInicio'];
    $fim = $_POST['dataFim'];
    $lancamentos = LancamentoDAO::getLancamentoByData($inicio, $fim);
    $tipoRelatorio = "Data";
} else {
    echo "<script>alert('Selecione um Lançamento!');window.location.replace('gerarRelatorio.php');</script>";
    exit;
}
if (count($lancamentos) == 0) {
    echo "<script>alert('Nenhum lançamento cadastrado com o(a) $tipoRelatorio selecionado!');window.location.replace('gerarRelatorio.php');</script>";
    exit;
}

$nomeArquivo = "relatorioCredores_" . date("d_m_Y") . ".csv";
header('Content-Type: application/csv');
header("Content-Disposition: attachment; filename=$nomeArquivo");
$fp = fopen('php://output', 'w');

$colunas = array("Id", "Credor", "Base", "Despesa", "Vencimento",
 mb_convert_encoding("Valor líquido", "ISO-8859-1", "UTF-8"), "Multa", 
 mb_convert_encoding("Juros", "ISO-8859-1", "UTF-8"), mb_convert_encoding("Correção", "ISO-8859-1", "UTF-8"), "Valor total");
fputcsv($fp, $colunas, ";");

foreach ($lancamentos as $lista) {
    
    $valorTotal = $lista->valorLiquido + $lista->valorCorrecao + $lista->valorMulta + $lista->valorJuros;

    $dadosCSV = $lista->getArrayCSV();

    $valorLiquido = number_format($lista->valorLiquido, 2, ',', '');
    $valorJuros = number_format($lista->valorJuros, 2, ',', '');

    $valorTotal = number_format($valorTotal, 2, ',', '');

    $dadosCSV['valorTotal'] = $valorTotal;

    fputcsv($fp, mb_convert_encoding($dadosCSV, 'Windows-1252', 'UTF-8'), ";");
}

fclose($fp);
?>
