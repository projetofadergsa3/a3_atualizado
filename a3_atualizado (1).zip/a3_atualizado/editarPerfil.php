<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EDITAR PERFIL</title>
</head>

<body>
    <br>

    <?php 
    $id= $_GET['id'];
    
 

    include_once ("dao/clsConexao.php");
  
    include_once ("model/clsPerfil.php");
    include_once ("dao/clsPerfilDAO.php");


    $perfil = PerfilDAO::getPerfilById($id);
    
    ?>

    <h1>Editar Perfil:</h1>
    <form method="POST" action="controller/salvarPerfil.php?editar&id=<?=$id ?>">
        <label>Nome: </label>
        <input type="text" value="<?=$perfil->nomePerfil ?>" name="txtNome" />
        <br><br>

        <input type="submit" value="Salvar alterações" />
    </form>
    <br>
    <hr>

</body>

</html>