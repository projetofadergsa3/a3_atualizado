<?php
session_start();

include_once("model/clsCredor.php");
include_once("dao/clsCredorDAO.php");
include_once("dao/clsConexao.php");

include_once("dao/clsUsuarioDAO.php");
include_once("model/clsUsuario.php");

if( !isset($_SESSION["logado"]) || $_SESSION["logado"] == false ){
    header("Location: index.php");
}else{

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Credores</title>
</head>

<body>
    <a href="sessao.php">
    <button>Voltar ao Início</button></a>

    <h1>Cadastro de Credores</h1>
    
    <form method="POST" action="controller/salvarCredor.php?inserir">
    <label for="nome" class="form-label">Nome do Credor:</label>
            <input class="form-control" type="text" name="txtNome" id="nome" required>
            <br>

            <label for="responsavel" class="form-label">Responsável:</label>
            <input class="form-control" type="text" name="txtResponsavel" id="responsavel" required>
            <br>

            <label for="telefone" class="form-label">Telefone:</label>
            <input class="form-control" type="text" name="txtTelefone" id="fone"
            placeholder='(00) 0000-0000'
            required>
            <br>

            <label for="celular" class="form-label">Celular:</label>
            <input class="form-control" type="text" name="txtCelular" id="cel"
            placeholder='(00) 0000-0000'
            required>
            <br>

            <select name="txtUsuario" required>
                <option value="">Selecione o Usuário que cadastrou </option>
                <?php
                    $usuario = UsuarioDAO::getUsuario();
                    foreach($usuario as $usu) {
                        echo '<option value="'.$usu->idUsuario.'">'.$usu->nomeUsuario.'</option>';
                    }
                ?>
            </select>
            <br>

            <input type="submit" value="Cadastrar Credor" class="btn btn-success mt-2">
    </form>
    <hr>

<?php
    $credores = CredorDAO::getCredor();

    if( count($credores) == 0 ){
        echo "<h1>Nenhum credor cadastrado!</h1>";
    }else{
?>
    <table border="1">
        <tr>
            <th>Id</th>
            <th>Nome</th>
            <th>Responsável</th>
            <th>Telefone</th>
            <th>Celular</th>
            <th>Editar</th>
            <th>Excluir</th>
        </tr>

        <?php
            
            foreach($credores as $cre){
                $id= $cre->idCredor;
                $nome=$cre->nomeCredor;
                $usuario=$cre->idUsuario;
                $responsavel=$cre->responsavelCredor;
                $telefone=$cre->telefoneCredor;
                $celular=$cre->celularCredor;
                echo "  <tr>
                            <td>$id</td>
                            <td>$nome</td>
                            <td>$responsavel</td>
                            <td>$telefone</td>
                            <td>$celular</td>
                            <td><a href='editarCredor.php?id=$id'><button>Editar</button></a></td>
                        
                        <td><a onclick='return confirm(\"Você tem certeza que deseja apagar?\")'
                        href='controller/salvarCredor.php?excluir&id=$id'>
                                <button>Excluir</button></a></td>
                        </tr>";
        }
        ?>
    </table>



    <?php

        }

        if( isset($_REQUEST["CredorExcluido"])){
            echo "<script> alert('Credor excluído com sucesso!'); </script>";
        }

        if( isset($_REQUEST["nomeCredor"])){
            $nome = $_REQUEST["nomeCredor"];
            echo "<script> alert('Credor $nome cadastrado com sucesso!'); </script>";
        }
    ?>

    <!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- jQuery Mask Plugin -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>


<script>
    $(document).ready(function(){
        $('#fone').mask('(00) 0000-0000');
        $('#cel').mask('(00) 00000-0000');
    });
</script>
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- jQuery Mask Plugin -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>

</script>
</body>

</html>
<?php
}
?>