<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EDITAR CREDOR</title>
</head>

<body>
    <br>

    <?php 
    $id= $_GET['id'];
    
 

    include_once ("dao/clsConexao.php");
  
    include_once ("model/clsCredor.php");
    include_once ("dao/clsCredorDAO.php");
    include_once ("model/clsUsuario.php");
    include_once ("dao/clsUsuarioDAO.php");

    $credor = CredorDAO::getCredorById($id);
    
    ?>

    <h1>Editar Credor:</h1>
    <form method="POST" action="controller/salvarCredor.php?editar&id=<?=$id ?>">
        <label>Nome: </label>
        <input type="text" value="<?=$credor->nomeCredor ?>" name="txtNome" />
        <br><br>
        <label>Responsável: </label>
        <textarea rows="10" cols="50" name="txtResponsavel"><?=$credor->responsavelCredor?></textarea>
        <br><br>
        <label>Telefone: </label>
        <input type="text" value="<?=$credor->telefoneCredor ?>" id="fone" name="txtTelefone" />
        <br><br>
        <label>Celular: </label>
        <input type="text" value="<?=$credor->celularCredor ?>" id="cel" name="txtCelular" />
        <br><br>
        <select name="txtUsuario" required>
                <option value="">Selecione o Usuário que cadastrou </option>
                <?php
                    $usuario = UsuarioDAO::getUsuario();
                    foreach($usuario as $usu) {
                        echo '<option value="'.$usu->idUsuario.'">'.$usu->nomeUsuario.'</option>';
                    }
                ?>
            </select>
            <br>
        
        <input type="submit" value="Salvar alterações" />
    </form>
    <br>
    <hr>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- jQuery Mask Plugin -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>


<script>
    $(document).ready(function(){
        $('#fone').mask('(00) 0000-0000');
        $('#cel').mask('(00) 00000-0000');
    });
</script>

</body>

</html>