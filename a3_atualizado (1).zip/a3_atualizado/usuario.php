<?php
session_start();

include_once ("dao/clsConexao.php");
include_once ("model/clsPerfil.php");
include_once ("dao/clsPerfilDAO.php");
include_once ("model/clsUsuario.php");
include_once ("dao/clsUsuarioDAO.php");

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <a href="sessao.php">
    <button>Voltar ao início</button></a>
    <title>Cadastro de Usuário</title>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
</head>
<body>
    <div class="container">
        <h1>Cadastro de Usuário</h1>
        <form id="cadastroForm" method="post" action="controller/salvarUsuario.php?inserir">
            <label for="nome" class="form-label">Nome Completo:</label>
            <input class="form-control" type="text" name="txtNome" id="nome" required>
            <br>
            <label for="email" class="form-label">E-mail:</label>
            <input class="form-control" type="email" name="txtEmail" id="email" required>
            <br>
            <label for="login" class="form-label">Login de Usuário:</label>
            <input class="form-control" type="text" name="txtLogin" id="login" required>
            <br>
            <label for="senha" class="form-label">Senha:</label>
            <input class="form-control" type="password" name="txtSenha" id="senha" required>
            <br>
            <label for="celular" class="form-label">Telefone Celular:</label>
            <input class="form-control" type="tel" name="txtCelular" id="cel" placeholder='(00) 0000-0000' required>
            <br>
            <label>Perfil:</label>
            <select name="txtPerfil" required>
                <option value="">Selecione... </option>
                <?php
                    $perfil = PerfilDAO::getPerfil();
                    foreach($perfil as $per) {
                        echo '<option value="'.$per->idPerfil.'">'.$per->nomePerfil.'</option>';
                    }
                ?>
            </select>
            <br>
            <input type="submit" value="Cadastrar Usuário" class="btn btn-success mt-2">
            <input type="reset" value="Limpar" class="btn btn-success mt-2">
            
        </form>

        <?php
            if (isset($_REQUEST["nomeVazio"])) {
                echo "<script> alert('O campo nome não pode ser vazio!'); </script>";
            }

            if (isset($_REQUEST["usuarioExcluido"])) {
                echo "<script> alert('Usuário excluído com sucesso!'); </script>";
            }

            if (isset($_REQUEST["nome"])) {
                $nome = $_REQUEST["nome"];
                echo "<script> alert('Usuário(a) $nome cadastrado(a) com sucesso!'); </script>";
            }
        ?>
    </div>

    <script>
        $(document).ready(function() {
            $('#cel').mask('(00) 00000-0000');

            $('#cadastroForm').submit(function(e) {
                var email = $('#email').val();

                var regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!regex.test(email)) {
                    alert('Por favor, insira um endereço de e-mail válido.');
                    e.preventDefault();
                }
            });
        });
    </script>

    <?php
    
if( isset($_SESSION["logado"])){
    $usuario = UsuarioDAO::getUsuario();

    if( count($usuario) == 0 ){
        echo "<h1>Nenhum Perfil cadastrado!</h1>";
    }else{
?>
    <h1>Editar/Excluir seu usuário</h1>
    <table border="1">
        <tr>
            <th>Id</th>
            <th>Nome</th>
            <th>Editar</th>
            <th>Excluir</th>
        </tr>

        <?php

if (isset($_SESSION["idUsuario"])) {
    foreach ($usuario as $usu) {
        $id = $usu->idUsuario;
        $nome = $usu->nomeUsuario;
        
            echo "<tr>
                    <td>$id</td>
                    <td>$nome</td>
                    <td><a href='editarUsuario.php?id=$id'><button>Editar</button></a></td>
                    <td><a onclick='return confirm(\"Você tem certeza que deseja apagar?\")'
                           href='controller/salvarUsuario.php?excluir&id=$id'>
                           <button>Excluir</button></a></td>
                  </tr>";
        }
    }
}   
        ?>
        </table>
     <?php
    }

    ?>           
</body>

</html>

