<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projeto A3</title></head>

<body>
    <div class="container">
        <h1 class="text-center bg-secondary-subtle p-3">Projeto A3 - Página Inicial</h1>
        <h2>Login de Usuário</h2>
        <form method="post" action="controller/logar.php">
            <label for="login" class="form-label">Login de Usuário:</label>
            <input class="form-control" type="text" name="txtLogin" id="login" required>

            <label for="senha" class="form-label">Senha:</label>
            <input class="form-control" type="password" name="txtSenha" id="senha" required>

            <input type="submit" value="Logar no Sistema" class="btn btn-primary mt-2">
        </form>
        <form method="post" action="usuario.php">
        <label for="text" class="form-label">Cadastro de usuário</label>
        <input type="submit" value="Cadastrar usuário" class="btn btn-primary mt-2">
        </form>
        <form method="post" action="perfil.php">
        <label for="text" class="form-label">Cadastro de Perfil</label>
        <input type="submit" value="Cadastrar usuário" class="btn btn-primary mt-2">
        </form>
    </div>
    <?php
    if(isset($_GET["deslogado"])){
        echo "<script>
                alert('Usuário deslogado com sucesso!');
            </script>";
    }

    if( isset($_REQUEST["usuarioInvalido"])){
        echo "<script> alert('Usuário/Senha inválidos!'); </script>";
    }
    ?>

</body>

</html>