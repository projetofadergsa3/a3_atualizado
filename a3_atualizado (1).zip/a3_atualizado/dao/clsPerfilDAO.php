<?php

class PerfilDAO{

    public static function inserir($perfil){
    $nome = $perfil->nomePerfil;      
    $sql = "INSERT INTO perfil (nomePerfil, ativo) VALUES ('$nome', 'S');";
    $id = Conexao::executarComRetornoId($sql);
    return $id;
            }
    public static function editar($nomePerfil, $idPerfil ){
    $nome = $nomePerfil;
    $id = $idPerfil;
    $sql = "UPDATE perfil SET nomePerfil = '$nome' WHERE idPerfil = $id ;" ;
            Conexao::executar( $sql );
            }
    public static function excluir($idPerfil){
            $sql = "DELETE FROM perfil WHERE idPerfil = $idPerfil ;";
            Conexao::executar($sql);
            }
    public static function getPerfil() {
    $sql = "SELECT idPerfil, nomePerfil FROM perfil ORDER BY nomePerfil";
    $result = Conexao::consultar($sql);
    $lista = new ArrayObject();
        if ($result != NULL) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $perfil = new Perfil();
                    $perfil->idPerfil = $row['idPerfil'];
                    $perfil->nomePerfil = $row['nomePerfil'];

                    $lista->append($perfil);
                    }
                }
                return $lista;
            }
            public static function getPerfilById($id) {
                $sql = "SELECT nomePerfil
                        FROM perfil
                        WHERE idPerfil = $id";
        
                $result = Conexao::consultar($sql);
                if ($result != NULL) {
                    $row = mysqli_fetch_assoc($result);
                    if ($row) {
                        $perfil = new Perfil();
                        $perfil->nomePerfil = $row['nomePerfil'];
                        return $perfil;
                    }
                }
                return null;
            }
        
}
?>