<?php


class LancamentoDAO{
    
    // INSERIR
    public static function inserir($lancamento) {
        $idDespesa = $lancamento->idDespesa;
        $competenciaDespesa = $lancamento->competenciaDespesa;
        $idUsuario = $lancamento->idUsuario;
        $idBase	= $lancamento->idBase;
        $dataVencimento	= $lancamento->dataVencimento;
        $valorLiquido = $lancamento->valorLiquido;
        $valorMulta = $lancamento->valorMulta;
        $valorJuros = $lancamento->valorJuros;
        $valorCorrecao = $lancamento->valorCorrecao;
        $observacao	= $lancamento->observacao;

        $sql = "INSERT INTO lancamento (idBase, idUsuario, idDespesa, competenciaDespesa, 
        dataVencimento, valorLiquido, valorMulta, valorJuros, valorCorrecao, ativo, observacao) VALUES
         ('$idBase','$idUsuario','$idDespesa','$competenciaDespesa', '$dataVencimento', '$valorLiquido',
         '$valorMulta', '$valorJuros', '$valorCorrecao','S','$observacao')";
        $id = Conexao::executarComRetornoId($sql);
        return $id;
    }

    // EDITAR
    public static function editar($idLancamento, $idBase, $idUsuario, $idDespesa, $competenciaDespesa, 
    $dataVencimento, $valorLiquido, $valorMulta, $valorJuros, $valorCorrecao, $observacao) {
        $id = $idLancamento;
        $base = $idBase;
        $usuario = $idUsuario;
        $despesa = $idDespesa;
        $competencia = $competenciaDespesa;
        $vencimento = $dataVencimento;
        $liquido = $valorLiquido;
        $multa = $valorMulta;
        $juros = $valorJuros;
        $correcao = $valorCorrecao;
        $observa = $observacao;

        $sql = "UPDATE lancamento SET 
                idBase = '$base',
                idUsuario = '$usuario',
                idDespesa = '$despesa',
                competenciaDespesa = '$competencia',
                dataVencimento = '$vencimento',
                valorLiquido = '$liquido',
                valorMulta = '$multa',
                valorJuros = '$juros',
                valorCorrecao = '$correcao',
                observacao = '$observa'
                WHERE idLancamento = $id";
        Conexao::executar($sql);
    }

    // EXCLUIR
    public static function excluir($idLancamento) {
        $sql = "DELETE FROM lancamento WHERE idLancamento = $idLancamento";
        Conexao::executar($sql);
    }

    // METODO CONSULTAR BANCO
    public static function getLancamento() {
        $sql = "SELECT l.idLancamento, b.idBase, b.nomeBase, u.idUsuario, u.nomeUsuario, d.idDespesa, d.nomeDespesa, 
         c.idCredor, c.nomeCredor, l.competenciaDespesa, l.dataVencimento, l.valorLiquido, l.valorMulta, 
         l.valorJuros, l.valorCorrecao, l.observacao

                FROM lancamento l 
                LEFT JOIN usuario u ON u.idUsuario = l.idUsuario
                LEFT JOIN base b ON b.idBase = l.idBase
                LEFT JOIN despesa d ON d.idDespesa = l.idDespesa
                LEFT JOIN credor c ON c.idCredor = d.idCredor
                ORDER BY l.idLancamento";
    $result = Conexao::consultar($sql);
    $lista = new ArrayObject();
    if($result != NULL){
        while(list($_idLancamento, $_idBase, $_nomeBase, $_idUsuario, $_nomeUsuario,
        $_idDespesa, $_nomeDespesa, $_idCredor, $_nomeCredor,
        $_competenciaDespesa, $_dataVencimento, $_valorLiquido,
        $_valorMulta, $_valorJuros, $_valorCorrecao, $_observacao) = mysqli_fetch_row($result)){
        $usuario=new Usuario();
        $usuario->idUsuario = $_idUsuario;
        $usuario->nomeUsuario = $_nomeUsuario;
        $credor = new Credor();
        $credor->idCredor = $_idCredor;
        $credor->nomeCredor = $_nomeCredor;

        $despesa= new Despesa();
        $despesa->idDespesa = $_idDespesa;
        $despesa->nomeDespesa = $_nomeDespesa;
        $despesa->idCredor=$credor;

        $base= new Base();
        $base->idBase = $_idBase;
        $base->nomeBase = $_nomeBase;


        $lancamento= new Lancamento();
        $lancamento->idLancamento=$_idLancamento;
        $lancamento->competenciaDespesa=$_competenciaDespesa;
        $lancamento->dataVencimento=$_dataVencimento;
        $lancamento->valorLiquido=$_valorLiquido;
        $lancamento->valorMulta=$_valorMulta;
        $lancamento->valorJuros=$_valorJuros;
        $lancamento->valorCorrecao=$_valorCorrecao;
        $lancamento->observacao=$_observacao;
        
        $lancamento->idDespesa=$despesa;
        $lancamento->idUsuario=$usuario;   
        $lancamento->idBase=$base; 
          

                $lista->append($lancamento);
            }
        }
        return $lista;
    }


    public static function getLancamentoById($idLancamento) {
        $sql = "SELECT l.idLancamento, l.idBase, d.idDespesa, d.nomeDespesa, l.competenciaDespesa, l.dataVencimento,
                       l.valorLiquido, l.valorMulta, l.valorJuros, l.valorCorrecao, l.observacao,
                        l.idUsuario,
                       c.nomeCredor, c.idCredor,
                       b.nomeBase
                FROM lancamento l
                LEFT JOIN despesa d ON d.idDespesa = l.idDespesa
                LEFT JOIN credor c ON c.idCredor = d.idCredor
                LEFT JOIN base b ON b.idBase = l.idBase
                WHERE l.idLancamento = $idLancamento";


        $result = Conexao::consultar($sql);
        if ($result != NULL) {
            $row = mysqli_fetch_assoc($result);
            if ($row) {
                $lancamento = new Lancamento();
                $lancamento->idDespesa = $row['idDespesa'];
                $lancamento->competenciaDespesa = $row['competenciaDespesa'];
                $lancamento->dataVencimento = $row['dataVencimento'];
                $lancamento->valorLiquido = $row['valorLiquido'];
                $lancamento->valorMulta = $row['valorMulta'];
                $lancamento->valorJuros = $row['valorJuros'];
                $lancamento->valorCorrecao = $row['valorCorrecao'];
                $lancamento->observacao = $row['observacao'];

                $credor = new Credor();
                $credor->idCredor = $row['idCredor'];
                $credor->nomeCredor = $row['nomeCredor'];

                $despesa = new Despesa();
                $despesa->idDespesa = $row['idDespesa'];
                $despesa->nomeDespesa = $row['nomeDespesa'];
                $despesa->idCredor = $credor;

                $base = new Base();
                $base->idBase = $row['idBase'];
                $base->nomeBase = $row['nomeBase'];

                $lancamento->idDespesa = $despesa;
                $lancamento->idBase = $base;

                return $lancamento;
            }
}
        return null;
}

public static function getLancamentoByIdBase($idBase) {
    $sql = "SELECT l.idLancamento, l.competenciaDespesa, l.dataVencimento,
                   l.valorLiquido, l.valorMulta, l.valorJuros, l.valorCorrecao, l.observacao,
                   d.idDespesa, d.nomeDespesa,
                   c.idCredor, c.nomeCredor,
                   b.idBase, b.nomeBase
            FROM lancamento l
            INNER JOIN despesa d ON d.idDespesa = l.idDespesa
            INNER JOIN credor c ON c.idCredor = d.idCredor
            INNER JOIN base b ON b.idBase = l.idBase
            WHERE l.idBase = $idBase";

    $result = Conexao::consultar($sql);
    $listaLancamentos = array(); // Array para armazenar os lançamentos encontrados

    if ($result != NULL && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $lancamento = new Lancamento();
            $lancamento->idLancamento = $row['idLancamento'];
            $lancamento->competenciaDespesa = $row['competenciaDespesa'];
            $lancamento->dataVencimento = $row['dataVencimento'];
            $lancamento->valorLiquido = $row['valorLiquido'];
            $lancamento->valorMulta = $row['valorMulta'];
            $lancamento->valorJuros = $row['valorJuros'];
            $lancamento->valorCorrecao = $row['valorCorrecao'];
            $lancamento->observacao = $row['observacao'];

            $credor = new Credor();
            $credor->idCredor = $row['idCredor'];
            $credor->nomeCredor = $row['nomeCredor'];

            $despesa = new Despesa();
            $despesa->idDespesa = $row['idDespesa'];
            $despesa->nomeDespesa = $row['nomeDespesa'];
            $despesa->idCredor = $credor;

            $base = new Base();
            $base->idBase = $row['idBase'];
            $base->nomeBase = $row['nomeBase'];

            $lancamento->idDespesa = $despesa;
            $lancamento->idBase = $base;

            $listaLancamentos[] = $lancamento; // Adiciona o lançamento ao array de resultados
        }
    }

    return $listaLancamentos; // Retorna a lista de lançamentos encontrados

        }
		public static function getLancamentoByIdCredor($idCredor) {
			$sql = "SELECT l.idLancamento, l.competenciaDespesa, l.dataVencimento,
						   l.valorLiquido, l.valorMulta, l.valorJuros, l.valorCorrecao, l.observacao,
						   d.idDespesa, d.nomeDespesa,
						   c.idCredor, c.nomeCredor,
						   b.idBase, b.nomeBase
					FROM lancamento l
					INNER JOIN despesa d ON d.idDespesa = l.idDespesa
					INNER JOIN credor c ON c.idCredor = d.idCredor
					INNER JOIN base b ON b.idBase = l.idBase
					WHERE d.idCredor = $idCredor";
		
			$result = Conexao::consultar($sql);
			$listaLancamentos = array(); // Array para armazenar os lançamentos encontrados
		
			if ($result != NULL && mysqli_num_rows($result) > 0) {
				while ($row = mysqli_fetch_assoc($result)) {
					$lancamento = new Lancamento();
					$lancamento->idLancamento = $row['idLancamento'];
					$lancamento->competenciaDespesa = $row['competenciaDespesa'];
					$lancamento->dataVencimento = $row['dataVencimento'];
					$lancamento->valorLiquido = $row['valorLiquido'];
					$lancamento->valorMulta = $row['valorMulta'];
                    $lancamento->valorJuros = $row['valorJuros'];
					$lancamento->valorCorrecao = $row['valorCorrecao'];
					$lancamento->observacao = $row['observacao'];
		
					$credor = new Credor();
					$credor->idCredor = $row['idCredor'];
					$credor->nomeCredor = $row['nomeCredor'];
		
					$despesa = new Despesa();
					$despesa->idDespesa = $row['idDespesa'];
					$despesa->nomeDespesa = $row['nomeDespesa'];
					$despesa->idCredor = $credor;
		
					$base = new Base();
					$base->idBase = $row['idBase'];
					$base->nomeBase = $row['nomeBase'];
		
					$lancamento->idDespesa = $despesa;
					$lancamento->idBase = $base;
		
					$listaLancamentos[] = $lancamento; // Adiciona o lançamento ao array de resultados
				}
			}
		
			return $listaLancamentos; // Retorna a lista de lançamentos encontrados
		}
		public static function getLancamentoByIdDespesa($idDespesa) {
			$sql = "SELECT l.idLancamento, l.competenciaDespesa, l.dataVencimento,
						   l.valorLiquido, l.valorMulta, l.valorJuros, l.valorCorrecao, l.observacao,
						   d.idDespesa, d.nomeDespesa,
						   c.idCredor, c.nomeCredor,
						   b.idBase, b.nomeBase
					FROM lancamento l
					INNER JOIN despesa d ON d.idDespesa = l.idDespesa
					INNER JOIN credor c ON c.idCredor = d.idCredor
					INNER JOIN base b ON b.idBase = l.idBase
					WHERE l.idDespesa = $idDespesa";
		
			$result = Conexao::consultar($sql);
			$listaLancamentos = array(); // Array para armazenar os lançamentos encontrados
		
			if ($result != NULL && mysqli_num_rows($result) > 0) {
				while ($row = mysqli_fetch_assoc($result)) {
					$lancamento = new Lancamento();
					$lancamento->idLancamento = $row['idLancamento'];
					$lancamento->competenciaDespesa = $row['competenciaDespesa'];
					$lancamento->dataVencimento = $row['dataVencimento'];
					$lancamento->valorLiquido = $row['valorLiquido'];
					$lancamento->valorMulta = $row['valorMulta'];
                    $lancamento->valorJuros = $row['valorJuros'];
					$lancamento->valorCorrecao = $row['valorCorrecao'];
					$lancamento->observacao = $row['observacao'];
		
					$credor = new Credor();
					$credor->idCredor = $row['idCredor'];
					$credor->nomeCredor = $row['nomeCredor'];
		
					$despesa = new Despesa();
					$despesa->idDespesa = $row['idDespesa'];
					$despesa->nomeDespesa = $row['nomeDespesa'];
					$despesa->idCredor = $credor;
		
					$base = new Base();
					$base->idBase = $row['idBase'];
					$base->nomeBase = $row['nomeBase'];
		
					$lancamento->idDespesa = $despesa;
					$lancamento->idBase = $base;
		
					$listaLancamentos[] = $lancamento; // Adiciona o lançamento ao array de resultados
				}
			}
		
			return $listaLancamentos; // Retorna a lista de lançamentos encontrados
				}
	public static function getLancamentoByData($inicio, $fim) {
					// Converte as datas para o formato esperado pelo banco de dados (se necessário)
					// Por exemplo, se estiver usando MySQL:
					// $inicio = date('Y-m-d', strtotime($inicio));
					// $fim = date('Y-m-d', strtotime($fim));
				
					$sql = "SELECT l.idLancamento, l.competenciaDespesa, l.dataVencimento,
								   l.valorLiquido, l.valorMulta, l.valorJuros, l.valorCorrecao, l.observacao,
								   d.idDespesa, d.nomeDespesa,
								   c.idCredor, c.nomeCredor,
								   b.idBase, b.nomeBase
							FROM lancamento l
							INNER JOIN despesa d ON d.idDespesa = l.idDespesa
							INNER JOIN credor c ON c.idCredor = d.idCredor
							INNER JOIN base b ON b.idBase = l.idBase
							WHERE l.dataVencimento BETWEEN '$inicio' AND '$fim'";
				
					$result = Conexao::consultar($sql);
					$listaLancamentos = array(); // Array para armazenar os lançamentos encontrados
				
					if ($result != NULL && mysqli_num_rows($result) > 0) {
						while ($row = mysqli_fetch_assoc($result)) {
							$lancamento = new Lancamento();
							$lancamento->idLancamento = $row['idLancamento'];
							$lancamento->competenciaDespesa = $row['competenciaDespesa'];
							$lancamento->dataVencimento = $row['dataVencimento'];
							$lancamento->valorLiquido = $row['valorLiquido'];
							$lancamento->valorMulta = $row['valorMulta'];
                            $lancamento->valorJuros = $row['valorJuros'];
							$lancamento->valorCorrecao = $row['valorCorrecao'];
							$lancamento->observacao = $row['observacao'];
				
							$credor = new Credor();
							$credor->idCredor = $row['idCredor'];
							$credor->nomeCredor = $row['nomeCredor'];
				
							$despesa = new Despesa();
							$despesa->idDespesa = $row['idDespesa'];
							$despesa->nomeDespesa = $row['nomeDespesa'];
							$despesa->idCredor = $credor;
				
							$base = new Base();
							$base->idBase = $row['idBase'];
							$base->nomeBase = $row['nomeBase'];
				
							$lancamento->idDespesa = $despesa;
							$lancamento->idBase = $base;
				
							$listaLancamentos[] = $lancamento; // Adiciona o lançamento ao array de resultados
						}
					}
				
					return $listaLancamentos; // Retorna a lista de lançamentos encontrados
				}
    }


