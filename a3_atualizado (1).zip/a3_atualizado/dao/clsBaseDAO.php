<?php

class BaseDAO {
    
    // INSERIR
    public static function inserir($base) {
        $nomeBase = $base->nomeBase;
        $responsavelBase = $base->responsavelBase;
        $telefoneBase = $base->telefoneBase;
        $celularBase = $base->celularBase;
        $emailBase = $base->emailBase;
        $idUsuario = $base->idUsuario;

        $sql = "INSERT INTO base (nomeBase, responsavelBase, telefoneBase, celularBase, emailBase, idUsuario, ativo) 
                VALUES ('$nomeBase', '$responsavelBase', '$telefoneBase', '$celularBase', '$emailBase', '$idUsuario','S')";
        $id = Conexao::executarComRetornoId($sql);
        return $id;
    }

    // EDITAR
    public static function editar($idBase, $nomeBase, $responsavelBase, $telefoneBase, $celularBase, $emailBase, $idUsuario) {
        $id = $idBase;
        $nome = $nomeBase;
        $responsavel = $responsavelBase;
        $telefone = $telefoneBase;
        $celular = $celularBase;
        $email = $emailBase;
        $usuario = $idUsuario;

        $sql = "UPDATE base SET 
                nomeBase = '$nome',
                responsavelBase = '$responsavel',
                telefoneBase = '$telefone',
                celularBase = '$celular',
                emailBase = '$email',
                idUsuario = $usuario
                WHERE idBase = $id ;";
        Conexao::executar($sql);
    }

    // EXCLUIR
    public static function excluir($idBase) {
        $sql = "DELETE FROM base WHERE idBase = $idBase ;";
        Conexao::executar($sql);
    }

    // METODO CONSULTAR BANCO
    public static function getBases() {
        $sql = "SELECT p.idBase, p.nomeBase, p.responsavelBase, p.telefoneBase, p.celularBase, p.emailBase,
          u.idUsuario, u.nomeUsuario
FROM base p 
LEFT JOIN usuario u ON u.idUsuario = p.idUsuario
ORDER BY p.nomeBase";

$result = Conexao::consultar($sql);
$lista = new ArrayObject();
if($result != NULL){
    while(list($_id, $_nome, $_responsavel, $_telefone, $_celular, $_email,
    $_idUsuario, $_nomeUsuario) = mysqli_fetch_row($result)){
        $usuario=new Usuario();
        $usuario->idUsuario = $_idUsuario;
        $usuario->nomeUsuario = $_nomeUsuario;

    $base= new Base();
    $base->idBase=$_id;
    $base->nomeBase=$_nome;
    $base->responsavelBase=$_responsavel;
    $base->telefoneBase=$_telefone;
    $base->celularBase=$_celular;
    $base->emailBase=$_email;
    $base->idUsuario=$usuario;       


        $lista->append($base);
    }
}
return $lista;
}

public static function getBaseById($idBase){
    $sql = "SELECT p.idBase, p.nomeBase, p.responsavelBase, p.telefoneBase, 
    p.celularBase, p.emailBase, p.idUsuario
from base p WHERE p.idBase = $idBase";
    
    $result = Conexao::consultar( $sql );
    if( $result != NULL ){
        $row = mysqli_fetch_assoc($result);
        if($row){
            $base = new Base();
            $base->nomeBase = $row['nomeBase'];
            $base->responsavelBase = $row['responsavelBase'];
            $base->telefoneBase = $row['telefoneBase'];
            $base->celularBase = $row['celularBase'];
            $base->nomeBase = $row['nomeBase'];
            $base->emailBase = $row['emailBase'];
            $base->idUsuario = $row['idUsuario'];
            return $base;
}
}
return null;
}


public static function getBaseByIdUsuario($idBase){

    $sql = "SELECT  p.idUsuario,
            c.idBase, c.nomeBase AS nomeUsuario
    from base p 
    LEFT JOIN usuario c ON c.idUsuario = p.idUsuario
    WHERE p.idBase = $idBase";
    
    $result = Conexao::consultar( $sql );
    if( $result != NULL ){
        $row = mysqli_fetch_assoc($result);
        if($row){
            $idUsuario = new Usuario();
            $idUsuario->idUsuario = $row['idUsuario'];
            $idUsuario->nomeUsuario = $row['nomeUsuario'];
            return $idUsuario;
        }
    }
    return null;
        }
    }


?>