<?php
include_once("dao/clsPerfilDAO.php");
include_once("model/clsPerfil.php");
class UsuarioDAO{


    public static function inserir($usuario){
        $nomeUsuario = $usuario->nomeUsuario;
        $emailUsuario = $usuario->emailUsuario;
        $loginUsuario = $usuario->loginUsuario;
        $senhaUsuario =  $usuario->senhaUsuario;
        $telefoneCelular = $usuario->telefoneCelular;
        $idPerfil = $usuario->idPerfil;
        
        $sql = "INSERT INTO usuario (nomeUsuario, idPerfil, loginUsuario, emailUsuario,
        senhaUsuario, telefoneCelular, ativo) VALUES ('$nomeUsuario', '$idPerfil', '$loginUsuario', '$emailUsuario',
        '$senhaUsuario', '$telefoneCelular', 'S')";
        $id = Conexao::executarComRetornoId($sql);
        return $id;
    }
    
    
public static function getUsuarioByLoginSenha($loginUsuario, $senhaUsuario){
    $sql = "SELECT idUsuario, nomeUsuario, emailUsuario
            FROM usuario 
            WHERE loginUsuario = '$loginUsuario' AND senhaUsuario = '$senhaUsuario' ";
          
    $result = Conexao::consultar($sql);
    if (mysqli_num_rows($result) == 0){
        return null;
    } else {
        $row = mysqli_fetch_assoc($result);
        $user = new Usuario();
        $user->idUsuario = $row['idUsuario'];
        $user->nomeUsuario = $row['nomeUsuario'];
        $user->emailUsuario = $row['emailUsuario'];
        return $user;
    }
}

    //EDITAR
public static function editar($idUsuario, $nomeUsuario, $loginUsuario, $emailUsuario, $senhaUsuario, $telefoneCelular, $idPerfil ){
    $id = $idUsuario;
    $nome = $nomeUsuario;
    $login = $loginUsuario;
    $email = $emailUsuario;
    $senha = $senhaUsuario;
    $telefone = $telefoneCelular;
    $perfil = $idPerfil;
    $sql = "UPDATE usuario SET 
            nomeUsuario = '$nome',
            loginUsuario = '$login',
            emailUsuario = '$email',
            senhaUsuario = '$senha',
            telefoneCelular = '$telefone',
            idPerfil = '$perfil'
            WHERE idUsuario = $id ;" ;
    Conexao::executar( $sql );
}

//EXCLUIRs
    public static function excluir($idUsuario){
            $sql = "DELETE FROM usuario WHERE idUsuario = $idUsuario;";
            Conexao::executar($sql);
            }

public static function getUsuario(){
    //retorna todas os clientes
    $sql = "SELECT p.idUsuario, p.loginUsuario, p.nomeUsuario, p.emailUsuario,
    p.senhaUsuario, p.telefoneCelular, c.idPerfil, c.nomePerfil
        FROM usuario p 
LEFT JOIN perfil c ON c.idPerfil = p.idPerfil
        ORDER BY p.nomeUsuario";
    
    $result = Conexao::consultar($sql);
    $lista = new ArrayObject();
    if($result != NULL){
        while(list($_idUsuario, $_idPerfil, $_nomeUsuario, $_nomePerfil, $_loginUsuario,
        $_emailUsuario, $_senhaUsuario, $_telefoneCelular) = mysqli_fetch_row($result)){
            $perfil=new Perfil();
            $perfil->idPerfil = $_idPerfil;
            $perfil->nomePerfil = $_nomePerfil;

        $usuario= new Usuario();
        $usuario->idUsuario=$_idUsuario;
        $usuario->nomeUsuario=$_nomeUsuario;
        $usuario->loginUsuario=$_loginUsuario;
        $usuario->emailUsuario=$_emailUsuario;
        $usuario->senhaUsuario=$_senhaUsuario;
        $usuario->telefoneCelular=$_telefoneCelular;
        $usuario->idPerfil=$perfil;       

            $lista->append($usuario);
        }
    }
    return $lista;
}

public static function getUsuarioById($idUsuario){
    $sql = "SELECT p.idUsuario, p.idPerfil, p.nomeUsuario, p.loginUsuario,
     p.emailUsuario, p.senhaUsuario, p.telefoneCelular
    from usuario p WHERE p.idUsuario = $idUsuario";
    
    $result = Conexao::consultar( $sql );
    if( $result != NULL ){
        $row = mysqli_fetch_assoc($result);
        if($row){
            $usuario = new Usuario();
            $usuario->nomeUsuario = $row['nomeUsuario'];
            $usuario->idPerfil = $row['idPerfil'];
            $usuario->loginUsuario = $row['loginUsuario'];
            $usuario->emailUsuario = $row['emailUsuario'];
            $usuario->senhaUsuario = $row['senhaUsuario'];
            $usuario->telefoneCelular = $row['telefoneCelular'];
            return $usuario;
}
}
return null;
}


public static function getPerfilByIdUsuario($idUsuario){

    $sql = "SELECT  c.idPerfil, p.idUsuario, p.nomeUsuario AS nomePerfil
            FROM usuario p 
            LEFT JOIN perfil c ON c.idPerfil = p.idPerfil
            WHERE p.idUsuario = $idUsuario";
    
    $result = Conexao::consultar( $sql );
    if( $result != NULL ){
        $row = mysqli_fetch_assoc($result);
        if($row){
            $idPerfil = new Perfil();
            $idPerfil->idPerfil = $row['idPerfil'];
            $idPerfil->nomePerfil = $row['nomePerfil'];
            return $idPerfil;
        }
    }
    return null;
        }
    }


?>