<?php

include_once("model/clsCredor.php");
include_once("dao/clsCredorDAO.php");
class DespesaDAO {
    
    // INSERIR
    public static function inserir($despesa) {
        $nomeDespesa = $despesa->nomeDespesa;
        $idUsuario = $despesa->idUsuario;
        $idCredor = $despesa->idCredor;
        

        $sql = "INSERT INTO despesa (idCredor, idUsuario, nomeDespesa, ativo) VALUES
         ('$idCredor','$idUsuario','$nomeDespesa','S')";
        $id = Conexao::executarComRetornoId($sql);
        return $id;
    }

    // EDITAR
    public static function editar($idDespesa, $idCredor, $idUsuario, $nomeDespesa) {
        $id = $idDespesa;
        $nome = $nomeDespesa;
        $credor = $idCredor;
        $usuario = $idUsuario;

        $sql = "UPDATE despesa SET 
                idCredor = '$credor',
                idUsuario = '$usuario',
                nomeDespesa = '$nome'
                WHERE idDespesa = $id";
        Conexao::executar($sql);
    }

    // EXCLUIR
    public static function excluir($idDespesa) {
        $sql = "DELETE FROM despesa WHERE idDespesa = $idDespesa";
        Conexao::executar($sql);
    }

    // METODO CONSULTAR BANCO
    public static function getDespesas() {
        $sql = "SELECT d.idDespesa, d.nomeDespesa, u.idUsuario, u.nomeUsuario,
        c.idCredor, c.nomeCredor
        FROM despesa d LEFT JOIN usuario u ON u.idUsuario = d.idUsuario
        LEFT JOIN credor c ON c.idCredor = d.idCredor
        ORDER BY nomeDespesa";
    $result = Conexao::consultar($sql);
    $lista = new ArrayObject();
    if($result != NULL){
        while(list($_idDespesa, $_nomeDespesa, $_idUsuario, $_nomeUsuario, $_idCredor, $_nomeCredor) = mysqli_fetch_row($result)){
        $usuario=new Usuario();
        $usuario->idUsuario = $_idUsuario;
        $usuario->nomeUsuario = $_nomeUsuario;

        $credor= new Credor();
        $credor->idCredor=$_idCredor;
        $credor->nomeCredor=$_nomeCredor;

        $despesa= new Despesa();
        $despesa->idDespesa=$_idDespesa;
        $despesa->nomeDespesa=$_nomeDespesa;
        $despesa->idUsuario=$usuario;
        $despesa->idCredor=$credor;      

                $lista->append($despesa);
            }
        }
        return $lista;
    }

    public static function getDespesaById($idDespesa) {
        $sql = "SELECT p.idDespesa, p.nomeDespesa, p.idUsuario, p.idCredor
                FROM despesa p
                WHERE idDespesa = $idDespesa";

        $result = Conexao::consultar($sql);
        if ($result != NULL) {
            $row = mysqli_fetch_assoc($result);
            if ($row) {
                $despesa = new Despesa();
                $despesa->nomeDespesa = $row['nomeDespesa'];
                $despesa->idUsuario = $row['idUsuario'];
                $despesa->idCredor = $row['idCredor'];

                return $despesa;
            }
}
        return null;
}

    public static function getDespesaByIdUsuario($idDespesa){

    $sql = "SELECT  c.idUsuario,
            u.idDespesa, u.nomeDespesa AS nomeUsuario
    from despesa c 
    LEFT JOIN usuario u ON u.idUsuario = c.idUsuario
    WHERE c.idDespesa = $idDespesa";
    
    $result = Conexao::consultar( $sql );
    if( $result != NULL ){
        $row = mysqli_fetch_assoc($result);
        if($row){
            $idUsuario = new Usuario();
            $idUsuario->idUsuario = $row['idUsuario'];
            $idUsuario->nomeUsuario = $row['nomeUsuario'];
            return $idUsuario;
        }
    }
    return null;
        }
}